<main class="my-auto p-5" id="content">
    <div class="text-center py-5">
  		<h1 class="display-4">ไม่พบการค้นหา</h1>
  		<h4>น่าเสียดาย ลองตรวจสอบคำค้นหาอีกครั้ง</h4>
	</div>
</main>